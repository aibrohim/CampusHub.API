﻿namespace CampusHub.Api.Settings;

public class ApiSpecialSettings
{
    public string HelloMessage { get; private set; }
}
