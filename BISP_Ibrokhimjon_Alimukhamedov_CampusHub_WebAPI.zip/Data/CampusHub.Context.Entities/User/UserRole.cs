﻿namespace CampusHub.Context.Entities;

public enum UserRole
{
    Student,
    Admin
}
