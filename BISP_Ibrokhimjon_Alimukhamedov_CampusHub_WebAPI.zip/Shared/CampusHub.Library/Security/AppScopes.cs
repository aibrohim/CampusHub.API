﻿namespace CampusHub.Common.Security;

public static class AppScopes
{
    public const string BooksRead = "books_read";
    public const string BooksWrite = "books_write";
}