﻿using System;
namespace CampusHub.Services.Identity;

public class StudentRegisterModel
{
}

