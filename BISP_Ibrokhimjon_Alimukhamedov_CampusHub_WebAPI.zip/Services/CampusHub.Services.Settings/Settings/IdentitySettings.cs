﻿namespace CampusHub.Services.Settings;

public class IdentitySettings
{
    public string Url { get; private set; }
}
